PlayWavePackage
===============

A simple visual component to play WAVe files in Windows or Linux

Licence
=======
LGPLv2

Author
======
minesadorada

Compatibility
=============
Tested in:
Windows Vista 32-bit
Linux Mint 64-bit

Should work with:
All versions of Windows
Most versions of Linux
Maybe Macintosh OSX

:Gordon Bamber September 2014