--> JANUARY 2017 Please read! <--
* LazAutoUpdate at V0.2.2.0
* Works with SourceForge and GitHub
* Comaptible with Laz1.6 onwards
* Also available via OnlinePackageManager
* Note change from generic updatehm.exe to OS-specific filenames
* For more information, see: http://wiki.lazarus.freepascal.org/LazAutoUpdater
* Latest files available via SVN. https://svn.code.sf.net/p/lazarus-ccr/svn/components/lazautoupdate/latest_stable/

Files in this section
=====================
All latest LazAutoUpdate component files are in svn
lazautoupdate.zip is the latest source code
updatepacksourcexxxx.zip is the source for the maintainer app
For a complete installation, read readme_completeautoupdatesource.txt

Lazarus Auto Update (lazautoupdate)
===================================

Summary
=======
LazAutoUpdate is a Lazarus visual component

* It is aimed at developers who maintain their application via a SourceForge project
* Tested for Windows and Linux
* For more information, visit: http://wiki.lazarus.freepascal.org/LazAutoUpdater
* Download the demo application to test
* Download the source from the Code/SVN archive to install the LazAutoUpdate package

License
=======
LGPLv2


Use
===

* The developer drops the component onto the application's main form and:
  * Sets the SourceForge project name property i.e. 'lazautoupdate'
  * Constructs and uploads an ini file with the version string 
  * Makes a ZIP file with the latest executable and a 'whatsnew.txt' describing the update
  * Makes an 'updates' folder in the files section of the SourceForge project
  * Uploads the ini file and the zipfile to the SourceForge /updates folder

* The app can now use the simple lazautoupdate methods:
    function NewVersionAvailable: boolean;
    function DownloadNewVersion: boolean;
    function UpdateToNewVersion: boolean;

* From then on, deploying an update means simply updating the version ini file, contructing a new ZIPfile and uploading them
* The Application can 'Check for Updates' at startup, or via a menu option.  The update is tranparent for the user


- Gordon Bamber
September 2014 
